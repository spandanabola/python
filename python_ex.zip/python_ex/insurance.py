import csv
import matplotlib.pyplot as plt
from math import sqrt
from sklearn import linear_model
import numpy as np

def mean(x):
	return sum(map(float,x))/float(len(x))

def variance(x, mean):
	return sum([(value-mean)**2 for value in map(float,x)])
	


# Calculate covariance between x and y
def covariance(x, mean_x, y, mean_y):
	#return sum([((X-mean_x)*(Y-mean_y)) for X,Y in x,y])
	covar = 0.0
	for i in range(len(x)):
		covar += (x[i] - mean_x) * (y[i] - mean_y)
	return covar

def coefficients(x, mean_x, y, mean_y):

	b1 = covariance(x, mean_x, y, mean_y) / variance(x, mean_x)
	b0 = mean_y - b1 * mean_x
	return [b0, b1]

def rmse_metric(actual, predicted):
	sum_error = 0.0
	for i in range(len(actual)):
		prediction_error = predicted[i] - actual[i]
		sum_error += (prediction_error ** 2)
	mean_error = sum_error / float(len(actual))
	return sqrt(mean_error)
	
with open("insurance.csv","rb") as csvdata:
	reader=csv.reader(csvdata, delimiter=',')
	x=[]
	y=[]
	for row in reader:
		x.append(row[0])
		y.append(row[1])
	del x[0]
	del y[0]
	print x
	print y
	mean_x, mean_y = mean(x), mean(y)
	var_x, var_y = variance(x, mean_x), variance(y, mean_y)
	print('x stats: mean=%.3f variance=%.3f' % (mean_x, var_x))
	print('y stats: mean=%.3f variance=%.3f' % (mean_y, var_y))
	covar = covariance(map(float,x), mean_x, map(float,y), mean_y)
	print('Covariance: %.3f' % (covar))
	b0, b1 = coefficients(map(float,x),mean_x,map(float,y),mean_y)
	print('Coefficients: B0=%.3f, B1=%.3f' % (b0, b1))
	predi=[(b0+b1*X) for X in map(float,x)]
	rmse=rmse_metric(map(float,y), predi);
	print('Root mean square error: %.3f' % (rmse))
	#plt.plot(map(float,x),map(float,y),'ro',map(float,x),predi,'b')
	#plt.show()
	
	X=np.array(map(float,x))
	Y=np.array(map(float,y))
	m=(((np.mean(X)*np.mean(Y))-np.mean(X*Y))/((np.mean(X)*np.mean(X))-np.mean(X*X)))
	b=(np.mean(Y)-np.mean(X)*m)
	reg_line=[m*x+b for x in X]
	
	plt.plot(X,Y,'ro',X,reg_line,'b')
	plt.show()
	# lm = linear_model.LinearRegression()
	# model = lm.fit(map(float,x),map(float,y));
	
	# predictions = lm.predict(map(float,x));
	
	# rmse=rmse_metric(map(float,y), predictions);
	# print('Root mean square error: %.3f' % (rmse))
	# lm.score(map(float,x),map(float,y))
	
	
