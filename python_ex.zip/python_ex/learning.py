from statistics import mean
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import style

# style.use("fivethirtyeight")

xm=np.array([18.34470085,79.86537666,85.09787509,10.52110327,44.45558653,69.56726251,8.959848679,86.196964,66.85655694,16.87490807],dtype=np.float64)
ym=np.array([5.072227705,7.15881537,7.262764628,4.254581322,6.281866658,6.911787335,4.043809747,7.259528698,6.898089228,4.874417979],dtype=np.float64)

from scipy.interpolate import *
p1=polyfit(xm,ym,1)

print (p1)

plot(xm,ym,'o')

plot(xm,polyval(p1,xm))

show()

# def best_fit(xm,ym):
	# m=((mean(xm)*mean(ym))-mean(xm*ym))/((mean(xm)*mean(xm))-mean(xm*xm))
	# b=mean(ym)-m*mean(xm)
	# return (m,b)

# (m,b)=best_fit(xm,ym)

# print(m,b)

# regression=[(m*x+b) for x in xm]

# plt.scatter(xm,ym)
# plt.plot(xm,regression)
# plt.show()