# -*- coding: utf-8 -*-
"""
Created on Wed Nov 01 16:35:46 2017

@author: dnathani
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Oct 31 19:41:19 2017

@author: dnathani
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Oct 30 10:05:36 2017

@author: dnathani
"""


from sklearn import linear_model
from sklearn import datasets
import pandas as pd
import numpy as np
from sklearn import cross_validation
from sklearn.preprocessing import PolynomialFeatures
from sklearn.svm import SVR 


def mse(x,y):
    return (np.mean((x-y)**2))

df = pd.read_csv("Book2.csv")


data=np.array(df.drop(['Price/SQFT'], 1))
target=np.array(df['Price/SQFT'])

X_train, X_test, y_train, y_test = cross_validation.train_test_split(data, target, test_size=0.2,random_state=3)
#lr=SVR(kernel="poly")
lr = linear_model.LinearRegression()
model = lr.fit(X_train,y_train)
predictions = model.predict(X_test)
err=mse(predictions,y_test)
print("This is mean square error for Linear: "+str(err))
                      
#include_bias is to add all the polynomial with all the power equal to '0'
poly = PolynomialFeatures(degree=3,include_bias=False)
data_new = poly.fit_transform(X_train)
data_test = poly.fit_transform(X_test)      
lr2 = linear_model.LinearRegression()
model2 = lr2.fit(data_new,y_train)
predictions2 = model2.predict(data_test)
print(y_test)
print(predictions2)

err2=mse(predictions2,y_test)

print("This is mean square error for Non-Linear: "+str(err2))

#instance=[0.17171,25,5.13,0,0.453,5.966,93.4,6.8185,8,284,19.7,378.08,14.44]
#poly2 = PolynomialFeatures(degree=2,include_bias=False)
#instance_new = poly2.fit_transform(instance)
#result=model2.predict(instance_new)
#result2=model.predict(instance)

#print("This is Your Result for an instance using non linear technique:"+str(result))
#print("This is Your Result for an instance using linear technique:"+str(result2))
print("This is Accuracy for Linear Regression : "+str(lr.score(X_test,y_test)*100))
print("This is Accuracy for Non Linear Regression : "+str(lr2.score(data_test,y_test)*100))




print(lr.coef_)
print(lr.intercept_)
print(lr2.coef_)
print(lr2.intercept_)