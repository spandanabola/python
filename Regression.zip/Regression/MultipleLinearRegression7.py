# -*- coding: utf-8 -*-
"""
Created on Fri Nov 03 12:02:47 2017

@author: dnathani
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Nov 02 18:19:09 2017

@author: dnathani
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Nov 01 16:35:46 2017

@author: dnathani
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Oct 31 19:41:19 2017

@author: dnathani
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Oct 30 10:05:36 2017

@author: dnathani
"""


from sklearn import linear_model
from sklearn import datasets
import pandas as pd
import numpy as np
from sklearn import cross_validation
from sklearn.preprocessing import PolynomialFeatures
from sklearn.svm import SVR 


def mse(x,y):
    return (np.mean((x-y)**2))

df = pd.read_csv("housing2.csv")
#df2 = pd.read_csv("housingTest.csv")
LabelName='MEDV'

data=np.array(df.drop([LabelName], 1))
target=np.array(df[LabelName])
#X_test=np.array(df2.drop([LabelName], 1))
#y_test=np.array(df2[LabelName])

X_train, X_test, y_train, y_test = cross_validation.train_test_split(data, target, test_size=0.2,random_state=6)
#lr=SVR(kernel="poly")

lr = linear_model.LinearRegression()
model = lr.fit(X_train,y_train)
predictions = model.predict(X_test)
err=mse(predictions,y_test)
print("This is mean square error for Linear: "+str(err))

NonLinearAcc=[]
for degreeValue in range(1,5):       
    #include_bias is to add all the polynomial with all the power equal to '0'
    poly = PolynomialFeatures(degree=degreeValue,include_bias=False)
    data_new = poly.fit_transform(X_train)
    data_test = poly.fit_transform(X_test)      
    lr2 = linear_model.LinearRegression()
    model2 = lr2.fit(data_new,y_train)
    predictions2 = model2.predict(data_test)
    NonLinearAcc.append(model2.score(data_test,y_test)*100)
poly = PolynomialFeatures(degree=(NonLinearAcc.index(max(NonLinearAcc))+1),include_bias=False)
data_new = poly.fit_transform(X_train)
data_test = poly.fit_transform(X_test)      
lr2 = linear_model.LinearRegression()
model2 = lr2.fit(data_new,y_train)
predictions2 = model2.predict(data_test)

print("OUTPUT: "+str(NonLinearAcc))    
print("Beat Power: "+str((NonLinearAcc.index(max(NonLinearAcc))+1)))
print("This is Accuracy for Linear Regression : "+str(lr.score(X_test,y_test)*100))
print("This is Accuracy for Non Linear Regression : "+str(lr2.score(data_test,y_test)*100))
print(lr.coef_)
print(lr.intercept_)
print(lr2.coef_)
print(lr2.intercept_)


###############################################################################

instance=[[4.83567,0,18.1,0,0.583,5.905,53.2,3.1523,24,666,20.2,388.22,11.45],[0.15086,0,27.74,0,0.609,5.454,92.7,1.8209,4,711,20.1,395.09,18.06],[0.18337,0,27.74,0,0.609,5.414,98.3,1.7554,4,711,20.1,344.05,23.97]]
#instance=[[504,504,504,504,504,504,504,504,504,504,504,504,4.83567,0,18.1,0,0.583,5.905,53.2,3.1523,24,666,20.2,388.22,11.45],
#         [505,505,505,505,505,505,505,505,505,505,505,505,0.15086,0,27.74,0,0.609,5.454,92.7,1.8209,4,711,20.1,395.09,18.06],
#         [506,506,506,506,506,506,506,506,506,506,506,506,0.18337,0,27.74,0,0.609,5.414,98.3,1.7554,4,711,20.1,344.05,23.97]]

poly2 = PolynomialFeatures(degree=(NonLinearAcc.index(max(NonLinearAcc))+1),include_bias=False)
instance_new = poly2.fit_transform(instance)
predictions_Data = model2.predict(instance_new)
print(predictions_Data)

