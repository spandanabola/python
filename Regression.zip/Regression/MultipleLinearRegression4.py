# -*- coding: utf-8 -*-
"""
Created on Wed Nov 01 11:07:19 2017

@author: dnathani
"""

from sklearn.linear_model import LinearRegression
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import PolynomialFeatures
import numpy as np


def mse(x,y):
    return (np.mean((x-y)**2))

x1=range(1,16)
x2=range(16,31)
data=zip(x1,x2)
print(x1)
print(x2)
temp1=[i ** 2+2*i+1 for i in x1]
temp2=[i ** 5+i ** 3 +4*i+4 for i in x2]
y=[a + b for a,b  in zip(temp1, temp2)]
print(y)

lr = LinearRegression()
model = lr.fit(data,y)
predictions = model.predict(data)
err=mse(predictions,y)
print("This is mean square error for Linear: "+str(err))
                      
#include_bias is to add all the polynomial with all the power equal to '0'
poly = PolynomialFeatures(degree=8,include_bias=False)
data_new = poly.fit_transform(data)
#data_test = poly.fit_transform(X_test)      
lr2 = LinearRegression()
model2 = lr2.fit(data_new,y)
predictions2 = model2.predict(data_new)
print(y)
print(predictions2)

err2=mse(predictions2,y)

print("This is mean square error for Non-Linear: "+str(err2))
m1=[16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60]
m2=[31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75]
instance=zip(m1,m2)
Correct_values=[28659070,33587332,39171466,45474868,52564894,60512980,69394762,79290196,90283678,102464164,115925290,130765492,147088126,165001588,184619434,206060500,229449022,254914756,282593098,312625204,345158110,380344852,418344586,459322708,503450974,550907620,601877482,656552116,715129918,777816244,844823530,916371412,992686846,1074004228,1160565514,1252620340,1350426142,1454248276,1564360138,1681043284,1804587550,1935291172,2073460906,2219412148,2373469054]
poly2 = PolynomialFeatures(degree=8,include_bias=False)
instance_new = poly2.fit_transform(instance)
result=model2.predict(instance_new)
result2=model.predict(instance)

print("This is Your Result for an instance using non linear technique:"+str(result))
print("This is Your Result for an instance using linear technique:"+str(result2))
print("This is Accuracy for Linear Regression : "+str(model.score(data,y)*100))
print("This is Accuracy for Non Linear Regression : "+str(model2.score(data_new,y)*100))

print("Accuracy for Linear test :"+str(model.score(instance,Correct_values)*100))
print("Accuracy for Non-Linear test :"+str(model2.score(instance_new,Correct_values)*100))


plt.plot(x1,y,"o")
plt.plot(x1,predictions2,"-r")