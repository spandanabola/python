# -*- coding: utf-8 -*-
"""
Created on Sun Oct 29 18:38:15 2017

@author: darshit.nj
"""

from sklearn import linear_model
from sklearn import datasets
import pandas as pd
import numpy as np
from sklearn import cross_validation

def mse(x,y):
    return (np.mean((x-y)**2))


df = pd.read_csv("housing2.csv")


data=np.array(df.drop(['MEDV'], 1))
target=np.array(df['MEDV'])

X_train, X_test, y_train, y_test = cross_validation.train_test_split(data, target, test_size=0.2)

lr = linear_model.LinearRegression()
print(y_train)
model = lr.fit(X_train,y_train)

predictions = lr.predict(X_train)
print(predictions)
print("This is the Accuracy : "+str(lr.score(X_train,y_train)))
print("This is the Mean square Error : "+str(mse(predictions,y_train)))

#acc=lr.score(predictions,y_test)
#print(acc)
print(lr.coef_)
print(lr.intercept_)


