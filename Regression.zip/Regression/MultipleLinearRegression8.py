# -*- coding: utf-8 -*-
"""
Created on Fri Nov 03 14:25:14 2017

@author: dnathani
"""

print(__doc__)

import numpy as np
from sklearn.svm import SVR
import matplotlib.pyplot as plt
import pandas as pd


df = pd.read_csv("housingTrain.csv")
df2 = pd.read_csv("housingTest.csv")
LabelName='MEDV'
# #############################################################################
# Generate sample data

X=np.array(df.drop([LabelName], 1))
y=np.array(df[LabelName])
X_test=np.array(df2.drop([LabelName], 1))
y_test=np.array(df2[LabelName])


# #############################################################################
# Fit regression model
svr_rbf = SVR(kernel='rbf', C=1e3, gamma=0.1)
svr_lin = SVR(kernel='linear', C=1e3)
svr_poly = SVR(kernel='poly', C=1e3, degree=2)
y_rbf = svr_rbf.fit(X, y).predict(X)
y_lin = svr_lin.fit(X, y).predict(X)
y_poly = svr_poly.fit(X, y).predict(X)


prediction=svr_poly.predict(X_test)
prediction2=svr_rbf.predict(X_test)
print(svr_poly.score(X_test, y_test))
print(svr_rbf.score(X_test, y_test))
print(svr_lin.score(X_test, y_test))

plt.plot(y, color='darkorange', label='data')
plt.plot(y_rbf, '-r', label='data')

for data in prediction:
    print(data)

for data in prediction2:
    print(data)
# #############################################################################
## Look at the results
#lw = 2
#plt.scatter(X, y, color='darkorange', label='data')
#plt.plot(X, y_rbf, color='navy', lw=lw, label='RBF model')
#plt.plot(X, y_lin, color='c', lw=lw, label='Linear model')
#plt.plot(X, y_poly, color='cornflowerblue', lw=lw, label='Polynomial model')
#plt.xlabel('data')
#plt.ylabel('target')
#plt.title('Support Vector Regression')
#plt.legend()
#plt.show()