# -*- coding: utf-8 -*-
"""
Created on Sun Oct 29 17:25:29 2017

@author: darshit.nj
"""

from sklearn.linear_model import LinearRegression
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


df = pd.read_csv("linearRegression.csv")


data=df["X_axies1"].tolist()
target=df["Y_axies"].tolist()

new_data=[]
new_target=[]

for content in data:
    new_data.append([int(content)])
for content in target:
    new_target.append(int(content))


lr=LinearRegression()

model=lr.fit(new_data,new_target)

prediction=model.predict([[21],[22]])

print(prediction)


plt.plot(new_data,new_target,"o")
plt.plot([[21],[22]],prediction,"x")