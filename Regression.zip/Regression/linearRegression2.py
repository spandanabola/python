# -*- coding: utf-8 -*-
"""
Created on Sun Oct 29 17:25:29 2017

@author: darshit.nj
"""

from sklearn.linear_model import LinearRegression
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("Stocks.csv")


data=df["TICKER"].tolist()
target=df["CLOSE"].tolist()

new_data=[]
new_target=[]

for content in data:
    new_data.append([int(content)])
for content in target:
    new_target.append(int(content))


lr=LinearRegression()

model=lr.fit(new_data,new_target)
prediction=model.predict(new_data)
plt.plot(new_data,new_target)
new_data2=[]
for data in range(2,201):
    new_data2.append([data])
prediction=model.predict(new_data2)

print(len(new_data))
print(len(prediction))
print(lr.coef_)
print(lr.intercept_)


plt.plot(new_data2,prediction,"r")